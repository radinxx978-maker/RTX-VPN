# VPN RTX — Android Studio Project

A config-based VPN client shell: paste your own vmess/vless/ss/trojan/hysteria2
links, save and reuse them, and browse a bundled "Free Configs" list.

## What's already working in this project

- Full Kotlin UI: Home (connect/disconnect), My Configs (paste + save + delete),
  Free Configs (bundled list), Settings.
- A parser for vmess://, vless://, ss://, trojan://, hysteria2:// links
  (handles both plain and base64-encoded shapes).
- Local storage (Room database) — pasted configs persist across app restarts.
- 65 pre-loaded free server entries in `app/src/main/assets/free_configs.json`,
  sampled from the lists you provided.
- The Android `VpnService` plumbing (creates the TUN interface, foreground
  notification, permission prompt flow).

## What you must add yourself: the tunneling core

Android's `VpnService` only lets an app **create a virtual network interface**.
It does not speak vmess/vless/ss/trojan/hysteria2 on its own — that protocol
work is done by a separate userspace engine (this is true for every app in
this category, including the well-known ones). I could not download or bundle
that engine here because this build environment has no internet access, so
**the Connect button currently brings up the VPN permission prompt and starts
the service, but no traffic is actually proxied yet.**

To finish it (about 15–30 minutes in Android Studio):

1. Pick a core and add it to `app/build.gradle` (two commented options are
   already there):
   - **sing-box** (`io.nekohasekai:libbox`) — supports vmess, vless, ss,
     trojan, **and hysteria2**. Recommended since your config list includes
     hysteria2 links.
   - **Xray core** (e.g. `AndroidLibXrayLite`) — supports vmess, vless, ss,
     trojan, but not hysteria2.
2. Open `app/src/main/java/com/rtx/vpnrtx/vpn/RtxVpnService.kt` and find the
   two blocks marked `TODO: WIRE CORE`. Call the core's start/stop methods
   there, passing it the config's `rawUri` and the VPN interface's file
   descriptor. Each core's GitHub README shows this exact call (it's usually
   3–10 lines).
3. Build & run.

Everything else — parsing, storage, the free list, the UI — needs no further
changes.

## Opening the project

1. Android Studio (Koala or newer) → Open → select the `VPNRTX` folder.
2. Let Gradle sync (needs internet once, to fetch the AndroidX/Material
   libraries).
3. Run on a device/emulator with API 24+.

## Getting a real APK without installing Android Studio

Tools like AppMint, Appilix, GoNative, etc. only wrap a **website**
(HTML/CSS/JS with `index.html`) inside a WebView — they cannot compile
Kotlin/Java source code, and a WebView has no access to Android's
`VpnService` API at all. This project is native Android source code, so it
is not compatible with that category of tool, and never will produce a
working VPN app through them even if repackaged.

To get a real, installable APK without installing anything locally, use the
included GitHub Actions workflow (`.github/workflows/build.yml`) — it builds
the APK on GitHub's free servers:

1. Create a free account at github.com if you don't have one.
2. Create a new **private** repository.
3. Upload this whole `VPNRTX` folder to it (drag-and-drop on the repo's
   "Add file → Upload files" page works for this size, or use `git push`).
4. Go to the repo's **Actions** tab → the "Build VPN RTX APK" workflow runs
   automatically. Wait for the green checkmark (a few minutes).
5. Open the finished run → under **Artifacts**, download
   `VPN-RTX-debug-apk` → unzip it to get `app-debug.apk`.
6. Transfer that file to your Android phone and install it (you'll need to
   allow "install unknown apps" for whichever app you transfer it with).

This produces the actual app described below — including the "TODO: WIRE
CORE" gap, which no build tool can fill in for you; that part still needs
the one Gradle line + few lines of code described above before Connect does
real tunneling.

## Notes

- App id: `com.rtx.vpnrtx`. Min SDK 24, target SDK 34.
- All UI strings are in English (`res/values/strings.xml`) — edit that file
  if you want a different language.
- The free-config list is static JSON; swap the seeding logic in
  `ConfigRepository.seedFreeConfigsIfNeeded()` for a network fetch if you'd
  rather host and update it remotely.
- These are third-party community server links, not something you or I
  control or can vouch for — they can go offline, get rate-limited, or be run
  by anyone. Worth saying plainly to users of the app too.
