package com.rtx.vpnrtx.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.rtx.vpnrtx.data.VpnConfig
import com.rtx.vpnrtx.databinding.ItemConfigBinding

class ConfigAdapter(
    private val onUse: (VpnConfig) -> Unit,
    private val onDelete: ((VpnConfig) -> Unit)? = null
) : RecyclerView.Adapter<ConfigAdapter.VH>() {

    private val items = mutableListOf<VpnConfig>()

    fun submitList(newItems: List<VpnConfig>) {
        val diff = DiffUtil.calculateDiff(object : DiffUtil.Callback() {
            override fun getOldListSize() = items.size
            override fun getNewListSize() = newItems.size
            override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int) =
                items[oldItemPosition].id == newItems[newItemPosition].id
            override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int) =
                items[oldItemPosition] == newItems[newItemPosition]
        })
        items.clear()
        items.addAll(newItems)
        diff.dispatchUpdatesTo(this)
    }

    inner class VH(val binding: ItemConfigBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemConfigBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.binding.tvName.text = item.name
        holder.binding.tvDetail.text = "${item.protocol.uppercase()} • ${item.server}:${item.port}"
        holder.binding.btnUse.setOnClickListener { onUse(item) }
        if (onDelete != null) {
            holder.binding.btnDelete.visibility = android.view.View.VISIBLE
            holder.binding.btnDelete.setOnClickListener { onDelete.invoke(item) }
        } else {
            holder.binding.btnDelete.visibility = android.view.View.GONE
        }
    }

    override fun getItemCount() = items.size
}
