package com.rtx.vpnrtx.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ConfigDao {

    @Query("SELECT * FROM configs WHERE source = 'user' ORDER BY addedAt DESC")
    fun observeUserConfigs(): Flow<List<VpnConfig>>

    @Query("SELECT * FROM configs WHERE source = 'free' ORDER BY addedAt DESC")
    fun observeFreeConfigs(): Flow<List<VpnConfig>>

    @Query("SELECT COUNT(*) FROM configs WHERE source = 'free'")
    suspend fun freeConfigCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(config: VpnConfig): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(configs: List<VpnConfig>)

    @Delete
    suspend fun delete(config: VpnConfig)

    @Query("SELECT * FROM configs WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): VpnConfig?
}
