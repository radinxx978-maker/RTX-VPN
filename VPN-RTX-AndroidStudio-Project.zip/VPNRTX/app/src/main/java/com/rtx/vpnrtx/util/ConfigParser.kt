package com.rtx.vpnrtx.util

import android.util.Base64
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.rtx.vpnrtx.data.VpnConfig
import java.net.URI
import java.net.URLDecoder

/**
 * Parses the config link formats produced by common V2Ray/Xray/sing-box
 * subscription generators: vmess://, vless://, ss://, trojan://, hysteria2://
 *
 * The parser only extracts display info (name/server/port) needed for the
 * UI. The full original URI is preserved untouched in [VpnConfig.rawUri]
 * so a wired-in core engine (see CoreConnectionAdapter) gets the exact
 * string it expects.
 */
object ConfigParser {

    class InvalidConfigException(message: String) : Exception(message)

    private val SUPPORTED_SCHEMES = setOf("vmess", "vless", "ss", "trojan", "hysteria2", "hy2")

    /** Splits a block of pasted text into individual config lines. */
    fun splitLines(raw: String): List<String> =
        raw.lines()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .filter { line -> SUPPORTED_SCHEMES.any { line.startsWith("$it://") } }

    fun parse(uri: String, source: String): VpnConfig {
        val scheme = uri.substringBefore("://", missingDelimiterValue = "")
        if (scheme !in SUPPORTED_SCHEMES) {
            throw InvalidConfigException("Unsupported or unrecognized config format")
        }
        return when (scheme) {
            "vmess" -> parseVmess(uri, source)
            "vless" -> parseGenericUserInfo(uri, source, "vless")
            "trojan" -> parseGenericUserInfo(uri, source, "trojan")
            "ss" -> parseShadowsocks(uri, source)
            "hysteria2", "hy2" -> parseGenericUserInfo(uri, source, "hysteria2")
            else -> throw InvalidConfigException("Unsupported config format")
        }
    }

    // vmess:// is base64(JSON) after the scheme
    private fun parseVmess(uri: String, source: String): VpnConfig {
        val b64 = uri.removePrefix("vmess://").substringBefore("#")
        val json = try {
            String(Base64.decode(b64, Base64.DEFAULT or Base64.NO_WRAP))
        } catch (e: Exception) {
            throw InvalidConfigException("Malformed vmess config")
        }
        val obj = try {
            Gson().fromJson(json, JsonObject::class.java)
        } catch (e: Exception) {
            throw InvalidConfigException("Malformed vmess JSON payload")
        }
        val server = obj.get("add")?.asString ?: throw InvalidConfigException("Missing server address")
        val port = obj.get("port")?.asString?.toIntOrNull() ?: 443
        val label = obj.get("ps")?.asString?.takeIf { it.isNotBlank() } ?: "VMess $server"
        return VpnConfig(
            name = cleanName(label),
            protocol = "vmess",
            server = server,
            port = port,
            rawUri = uri,
            source = source
        )
    }

    // vless / trojan / hysteria2 share the URI shape: scheme://userinfo@host:port?params#tag
    private fun parseGenericUserInfo(uri: String, source: String, protocol: String): VpnConfig {
        val fragment = uri.substringAfter("#", missingDelimiterValue = "")
        val tag = if (fragment.isNotBlank()) safeUrlDecode(fragment) else ""
        val withoutTag = uri.substringBefore("#")

        val parsed = try {
            URI(withoutTag)
        } catch (e: Exception) {
            throw InvalidConfigException("Malformed $protocol config")
        }
        val host = parsed.host ?: throw InvalidConfigException("Missing server address")
        val port = if (parsed.port > 0) parsed.port else 443
        val label = tag.takeIf { it.isNotBlank() } ?: "${protocol.uppercase()} $host"

        return VpnConfig(
            name = cleanName(label),
            protocol = protocol,
            server = host,
            port = port,
            rawUri = uri,
            source = source
        )
    }

    // ss:// has two historical shapes: base64(method:pass@host:port) or method:pass@host:port
    private fun parseShadowsocks(uri: String, source: String): VpnConfig {
        val fragment = uri.substringAfter("#", missingDelimiterValue = "")
        val tag = if (fragment.isNotBlank()) safeUrlDecode(fragment) else ""
        val body = uri.removePrefix("ss://").substringBefore("#")

        // Try the "plain" shape first: <userinfo>@host:port?params
        val atIndex = body.lastIndexOf('@')
        var host: String? = null
        var port = 443

        if (atIndex != -1) {
            val hostPart = body.substring(atIndex + 1).substringBefore("?")
            val hp = hostPart.split(":")
            if (hp.size >= 2) {
                host = hp[0]
                port = hp[1].toIntOrNull() ?: 443
            }
        }

        // Fallback: fully base64-encoded legacy shape
        if (host == null) {
            try {
                val decoded = String(Base64.decode(body.substringBefore("?"), Base64.DEFAULT or Base64.NO_WRAP))
                val hp = decoded.substringAfterLast('@')
                val parts = hp.split(":")
                if (parts.size >= 2) {
                    host = parts[0]
                    port = parts[1].toIntOrNull() ?: 443
                }
            } catch (_: Exception) {
                // leave host null, handled below
            }
        }

        val resolvedHost = host ?: throw InvalidConfigException("Malformed shadowsocks config")
        val label = tag.takeIf { it.isNotBlank() } ?: "SS $resolvedHost"

        return VpnConfig(
            name = cleanName(label),
            protocol = "ss",
            server = resolvedHost,
            port = port,
            rawUri = uri,
            source = source
        )
    }

    private fun safeUrlDecode(s: String): String =
        try { URLDecoder.decode(s, "UTF-8") } catch (_: Exception) { s }

    private fun cleanName(s: String): String =
        s.trim().take(60).ifBlank { "Unnamed server" }
}
