package com.rtx.vpnrtx.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.rtx.vpnrtx.R
import com.rtx.vpnrtx.ui.freeconfigs.FreeConfigsFragment
import com.rtx.vpnrtx.ui.home.HomeFragment
import com.rtx.vpnrtx.ui.myconfigs.MyConfigsFragment
import com.rtx.vpnrtx.ui.settings.SettingsFragment

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val nav = findViewById<BottomNavigationView>(R.id.bottom_nav)

        if (savedInstanceState == null) {
            showFragment(HomeFragment())
        }

        nav.setOnItemSelectedListener { item ->
            val fragment: Fragment = when (item.itemId) {
                R.id.nav_home -> HomeFragment()
                R.id.nav_my_configs -> MyConfigsFragment()
                R.id.nav_free_configs -> FreeConfigsFragment()
                R.id.nav_settings -> SettingsFragment()
                else -> HomeFragment()
            }
            showFragment(fragment)
            true
        }
    }

    private fun showFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }
}
