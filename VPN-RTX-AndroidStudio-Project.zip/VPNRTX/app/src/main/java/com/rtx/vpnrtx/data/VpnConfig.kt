package com.rtx.vpnrtx.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A single VPN server configuration, either pasted by the user or picked
 * from the bundled Free Configs list.
 */
@Entity(tableName = "configs")
data class VpnConfig(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val protocol: String,      // vmess | vless | ss | trojan | hysteria2
    val server: String,
    val port: Int,
    val rawUri: String,        // original pasted/imported URI, kept for the core engine
    val source: String,        // "user" or "free"
    val addedAt: Long = System.currentTimeMillis()
)
