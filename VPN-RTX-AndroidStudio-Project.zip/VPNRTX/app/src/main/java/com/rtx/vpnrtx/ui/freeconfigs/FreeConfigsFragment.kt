package com.rtx.vpnrtx.ui.freeconfigs

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.rtx.vpnrtx.data.ConfigRepository
import com.rtx.vpnrtx.data.VpnConfig
import com.rtx.vpnrtx.databinding.FragmentFreeConfigsBinding
import com.rtx.vpnrtx.ui.ConfigAdapter
import com.rtx.vpnrtx.vpn.ConnectionManager
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class FreeConfigsFragment : Fragment() {

    private var _binding: FragmentFreeConfigsBinding? = null
    private val binding get() = _binding!!
    private lateinit var repository: ConfigRepository
    private lateinit var adapter: ConfigAdapter

    private var pendingConnectConfig: VpnConfig? = null
    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            pendingConnectConfig?.let { ConnectionManager.connect(requireActivity(), it, vpnPermissionLauncher) }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFreeConfigsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        repository = ConfigRepository(requireContext())

        adapter = ConfigAdapter(onUse = { config ->
            pendingConnectConfig = config
            ConnectionManager.connect(requireActivity(), config, vpnPermissionLauncher)
        })
        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerView.adapter = adapter

        lifecycleScope.launch { repository.seedFreeConfigsIfNeeded() }

        lifecycleScope.launch {
            repository.observeFreeConfigs().collectLatest { list ->
                adapter.submitList(list)
                binding.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
