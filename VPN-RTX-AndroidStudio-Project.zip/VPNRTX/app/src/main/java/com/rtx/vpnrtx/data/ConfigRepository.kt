package com.rtx.vpnrtx.data

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.rtx.vpnrtx.util.ConfigParser
import kotlinx.coroutines.flow.Flow

/**
 * Bundled JSON entry shape for assets/free_configs.json
 */
private data class BundledFreeConfig(val id: Int, val name: String, val protocol: String, val uri: String)

class ConfigRepository(private val context: Context) {

    private val dao = AppDatabase.get(context).configDao()

    fun observeUserConfigs(): Flow<List<VpnConfig>> = dao.observeUserConfigs()
    fun observeFreeConfigs(): Flow<List<VpnConfig>> = dao.observeFreeConfigs()

    /** Parses pasted text (one or many config lines) and stores each as a user config. */
    suspend fun addUserConfigsFromText(rawText: String): Result<Int> {
        val lines = ConfigParser.splitLines(rawText)
        if (lines.isEmpty()) {
            return Result.failure(ConfigParser.InvalidConfigException("No valid config link found"))
        }
        var added = 0
        for (line in lines) {
            try {
                val cfg = ConfigParser.parse(line, source = "user")
                dao.insert(cfg)
                added++
            } catch (_: ConfigParser.InvalidConfigException) {
                // skip invalid line, keep processing the rest of the paste
            }
        }
        return if (added > 0) Result.success(added)
        else Result.failure(ConfigParser.InvalidConfigException("No valid config link found"))
    }

    suspend fun deleteConfig(config: VpnConfig) = dao.delete(config)

    /** Loads assets/free_configs.json into the DB once, on first app run. */
    suspend fun seedFreeConfigsIfNeeded() {
        if (dao.freeConfigCount() > 0) return
        val json = context.assets.open("free_configs.json").bufferedReader().use { it.readText() }
        val type = object : TypeToken<List<BundledFreeConfig>>() {}.type
        val bundled: List<BundledFreeConfig> = Gson().fromJson(json, type)

        val parsed = bundled.mapNotNull {
            try {
                ConfigParser.parse(it.uri, source = "free").copy(name = it.name)
            } catch (_: Exception) {
                null
            }
        }
        dao.insertAll(parsed)
    }
}
