package com.rtx.vpnrtx.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.rtx.vpnrtx.R
import com.rtx.vpnrtx.ui.MainActivity

/**
 * Foreground VpnService that owns the TUN interface lifecycle.
 *
 * This class establishes the Android-side VPN interface (the part the
 * OS actually requires a VpnService for). Routing the packets that come
 * out of that interface to a real vmess/vless/ss/trojan/hysteria2 server
 * requires a userspace proxy core (sing-box / Xray). That core is NOT
 * bundled in this project (see app/build.gradle comment) because it
 * needs network access to fetch, which isn't available in every build
 * environment automatically - you add it as one Gradle line.
 *
 * TODO: WIRE CORE
 * Once you've added the core dependency, replace the body of
 * [startTunnel] with a call to the core's start method, feeding it
 * [currentConfig].rawUri, and pass the returned tun2socks file
 * descriptor to `vpnInterface`.
 */
class RtxVpnService : VpnService() {

    companion object {
        const val ACTION_CONNECT = "com.rtx.vpnrtx.CONNECT"
        const val ACTION_DISCONNECT = "com.rtx.vpnrtx.DISCONNECT"
        const val EXTRA_CONFIG_URI = "extra_config_uri"
        const val EXTRA_CONFIG_NAME = "extra_config_name"
        const val EXTRA_CONFIG_PROTOCOL = "extra_config_protocol"
        private const val CHANNEL_ID = "vpnrtx_service"
        private const val NOTIF_ID = 1
    }

    private var vpnInterface: ParcelFileDescriptor? = null
    private var currentConfigUri: String? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CONNECT -> {
                currentConfigUri = intent.getStringExtra(EXTRA_CONFIG_URI)
                val name = intent.getStringExtra(EXTRA_CONFIG_NAME) ?: "VPN RTX"
                startForeground(NOTIF_ID, buildNotification(name))
                startTunnel()
            }
            ACTION_DISCONNECT -> {
                stopTunnel()
                stopSelf()
            }
        }
        return START_STICKY
    }

    private fun startTunnel() {
        val builder = Builder()
            .setSession("VPN RTX")
            .addAddress("10.10.0.2", 32)
            .addDnsServer("1.1.1.1")
            .addDnsServer("1.0.0.1")
            .addRoute("0.0.0.0", 0)
            .setMtu(1500)

        vpnInterface = builder.establish()

        // -----------------------------------------------------------
        // TODO: WIRE CORE
        // Hand `vpnInterface!!.fileDescriptor` and `currentConfigUri`
        // to the sing-box / Xray core here, e.g.:
        //   CoreConnectionAdapter.start(this, currentConfigUri, vpnInterface!!)
        // Without this step the TUN device is up but no traffic is
        // actually proxied yet - this file only covers the Android
        // VpnService plumbing.
        // -----------------------------------------------------------
    }

    private fun stopTunnel() {
        // TODO: WIRE CORE - also call the core's stop/close method here.
        vpnInterface?.close()
        vpnInterface = null
        currentConfigUri = null
    }

    private fun buildNotification(configName: String): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "VPN RTX Service", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("VPN RTX connected")
            .setContentText(configName)
            .setSmallIcon(R.drawable.ic_shield)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        stopTunnel()
        super.onDestroy()
    }
}
