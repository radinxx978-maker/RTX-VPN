package com.rtx.vpnrtx.vpn

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.VpnService
import androidx.activity.result.ActivityResultLauncher
import com.rtx.vpnrtx.data.VpnConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

enum class ConnectionState { DISCONNECTED, CONNECTING, CONNECTED }

/**
 * Thin wrapper the UI talks to. Handles the Android VpnService permission
 * prompt and starts/stops RtxVpnService. Actual tunneling behavior lives
 * in RtxVpnService + the core engine you wire in (see its TODOs).
 */
object ConnectionManager {

    private val _state = MutableStateFlow(ConnectionState.DISCONNECTED)
    val state: StateFlow<ConnectionState> = _state

    private val _activeConfig = MutableStateFlow<VpnConfig?>(null)
    val activeConfig: StateFlow<VpnConfig?> = _activeConfig

    /**
     * Call from an Activity. If the OS VPN permission dialog is needed,
     * launches [permissionLauncher] and the caller should re-invoke
     * connect() from the launcher's callback on success.
     */
    fun connect(activity: Activity, config: VpnConfig, permissionLauncher: ActivityResultLauncher<Intent>) {
        val prepareIntent = VpnService.prepare(activity)
        if (prepareIntent != null) {
            permissionLauncher.launch(prepareIntent)
            return
        }
        _state.value = ConnectionState.CONNECTING
        _activeConfig.value = config
        val intent = Intent(activity, RtxVpnService::class.java).apply {
            action = RtxVpnService.ACTION_CONNECT
            putExtra(RtxVpnService.EXTRA_CONFIG_URI, config.rawUri)
            putExtra(RtxVpnService.EXTRA_CONFIG_NAME, config.name)
            putExtra(RtxVpnService.EXTRA_CONFIG_PROTOCOL, config.protocol)
        }
        activity.startService(intent)
        // NOTE: without a wired core reporting real handshake success,
        // we optimistically flip to CONNECTED once the service starts.
        _state.value = ConnectionState.CONNECTED
    }

    fun disconnect(context: Context) {
        val intent = Intent(context, RtxVpnService::class.java).apply {
            action = RtxVpnService.ACTION_DISCONNECT
        }
        context.startService(intent)
        _state.value = ConnectionState.DISCONNECTED
        _activeConfig.value = null
    }
}
