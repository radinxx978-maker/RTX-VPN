package com.rtx.vpnrtx.ui.home

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.rtx.vpnrtx.data.ConfigRepository
import com.rtx.vpnrtx.data.VpnConfig
import com.rtx.vpnrtx.databinding.FragmentHomeBinding
import com.rtx.vpnrtx.vpn.ConnectionManager
import com.rtx.vpnrtx.vpn.ConnectionState
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    private lateinit var repository: ConfigRepository
    private var selectedConfig: VpnConfig? = null

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            selectedConfig?.let { ConnectionManager.connect(requireActivity(), it, vpnPermissionLauncher) }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        repository = ConfigRepository(requireContext())

        lifecycleScope.launch { repository.seedFreeConfigsIfNeeded() }

        // Default to the first saved user config, if any, else first free config
        lifecycleScope.launch {
            repository.observeUserConfigs().collectLatest { userConfigs ->
                if (selectedConfig == null) {
                    selectedConfig = userConfigs.firstOrNull()
                    updateSelectedLabel()
                }
            }
        }

        lifecycleScope.launch {
            ConnectionManager.state.collectLatest { state ->
                renderState(state)
            }
        }

        binding.btnConnect.setOnClickListener {
            val current = ConnectionManager.state.value
            if (current == ConnectionState.CONNECTED || current == ConnectionState.CONNECTING) {
                ConnectionManager.disconnect(requireContext())
            } else {
                val config = selectedConfig
                if (config == null) {
                    binding.tvSelectedConfig.text = getString(com.rtx.vpnrtx.R.string.home_no_config_selected)
                    return@setOnClickListener
                }
                ConnectionManager.connect(requireActivity(), config, vpnPermissionLauncher)
            }
        }
    }

    private fun updateSelectedLabel() {
        binding.tvSelectedConfig.text = selectedConfig?.name
            ?: getString(com.rtx.vpnrtx.R.string.home_no_config_selected)
    }

    private fun renderState(state: ConnectionState) {
        when (state) {
            ConnectionState.DISCONNECTED -> {
                binding.btnConnect.text = getString(com.rtx.vpnrtx.R.string.home_connect)
                binding.tvStatus.text = getString(com.rtx.vpnrtx.R.string.home_status_disconnected)
            }
            ConnectionState.CONNECTING -> {
                binding.btnConnect.text = getString(com.rtx.vpnrtx.R.string.home_cancel)
                binding.tvStatus.text = getString(com.rtx.vpnrtx.R.string.home_status_connecting)
            }
            ConnectionState.CONNECTED -> {
                binding.btnConnect.text = getString(com.rtx.vpnrtx.R.string.home_disconnect)
                binding.tvStatus.text = getString(com.rtx.vpnrtx.R.string.home_status_connected)
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
