package com.rtx.vpnrtx.ui.myconfigs

import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.snackbar.Snackbar
import com.rtx.vpnrtx.R
import com.rtx.vpnrtx.data.ConfigRepository
import com.rtx.vpnrtx.data.VpnConfig
import com.rtx.vpnrtx.databinding.FragmentMyConfigsBinding
import com.rtx.vpnrtx.ui.ConfigAdapter
import com.rtx.vpnrtx.vpn.ConnectionManager
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MyConfigsFragment : Fragment() {

    private var _binding: FragmentMyConfigsBinding? = null
    private val binding get() = _binding!!
    private lateinit var repository: ConfigRepository
    private lateinit var adapter: ConfigAdapter

    private var pendingConnectConfig: VpnConfig? = null
    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            pendingConnectConfig?.let { ConnectionManager.connect(requireActivity(), it, vpnPermissionLauncher) }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMyConfigsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        repository = ConfigRepository(requireContext())

        adapter = ConfigAdapter(
            onUse = { config ->
                pendingConnectConfig = config
                ConnectionManager.connect(requireActivity(), config, vpnPermissionLauncher)
            },
            onDelete = { config ->
                lifecycleScope.launch { repository.deleteConfig(config) }
            }
        )
        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerView.adapter = adapter

        lifecycleScope.launch {
            repository.observeUserConfigs().collectLatest { list ->
                adapter.submitList(list)
                binding.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            }
        }

        binding.btnPasteFromClipboard.setOnClickListener {
            val clipboard = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = clipboard.primaryClip
            if (clip != null && clip.itemCount > 0) {
                val text = clip.getItemAt(0).coerceToText(requireContext()).toString()
                binding.etConfigInput.setText(text)
            }
        }

        binding.btnAddConfig.setOnClickListener {
            val text = binding.etConfigInput.text?.toString().orEmpty()
            if (text.isBlank()) {
                Snackbar.make(binding.root, getString(R.string.myconfigs_empty_input), Snackbar.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            lifecycleScope.launch {
                val result = repository.addUserConfigsFromText(text)
                result.onSuccess { count ->
                    binding.etConfigInput.setText("")
                    Snackbar.make(
                        binding.root,
                        resources.getQuantityString(R.plurals.myconfigs_added, count, count),
                        Snackbar.LENGTH_SHORT
                    ).show()
                }.onFailure {
                    Snackbar.make(binding.root, getString(R.string.myconfigs_invalid_input), Snackbar.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
